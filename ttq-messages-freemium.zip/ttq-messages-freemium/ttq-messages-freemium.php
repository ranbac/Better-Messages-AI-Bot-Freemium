<?php
/**
 * Plugin Name: TTQ Messages Freemium
 * Description: Gating AI Chat Bots (Better Messages) theo PMPro membership level — mô hình Freemium cho tiengtrungquoc.net. Cấu hình tại wp-admin > Better Messages > TTQ Freemium.
 * Version:     1.1.0
 * Author:      TTQ
 * Text Domain: ttq-messages-freemium
 */

defined('ABSPATH') || exit;

/**
 * ============================================================
 * BOOTSTRAP
 * ============================================================
 */
add_action('plugins_loaded', function () {

    if (!function_exists('pmpro_hasMembershipLevel')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>TTQ Messages Freemium:</strong> cần plugin Paid Memberships Pro được kích hoạt.</p></div>';
        });
        return;
    }

    if (!function_exists('Better_Messages')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>TTQ Messages Freemium:</strong> cần plugin Better Messages được kích hoạt.</p></div>';
        });
        return;
    }

    require_once __DIR__ . '/inc/class-settings.php';
    require_once __DIR__ . '/inc/helpers.php';
    require_once __DIR__ . '/inc/class-ai-bot-gate.php';
    require_once __DIR__ . '/inc/class-ai-bot-limits.php';
    require_once __DIR__ . '/inc/class-pmpro-sync.php';

    TTQ_BM_Settings::init();
    TTQ_BM_AI_Bot_Gate::init();
    TTQ_BM_AI_Bot_Limits::init();
    TTQ_BM_PMPro_Sync::init();

}, 20);


/**
 * ============================================================
 * CRON: dọn dẹp user_meta đếm lượt sau 7 ngày
 * ============================================================
 */
register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('ttq_bm_cleanup_daily_counters')) {
        wp_schedule_event(time(), 'daily', 'ttq_bm_cleanup_daily_counters');
    }
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('ttq_bm_cleanup_daily_counters');
});

add_action('ttq_bm_cleanup_daily_counters', function () {
    global $wpdb;

    // key dạng _ttq_ai_YYYYMMDD -> xoá các key cũ hơn 7 ngày
    $cutoff = gmdate('Ymd', current_time('timestamp') - 7 * DAY_IN_SECONDS);

    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$wpdb->usermeta}
         WHERE meta_key LIKE %s
           AND meta_key REGEXP '^_ttq_ai_[0-9]{8}$'
           AND SUBSTRING(meta_key, 9) < %s",
        '_ttq_ai_%',
        $cutoff
    ));
});
