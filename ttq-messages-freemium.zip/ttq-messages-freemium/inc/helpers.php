<?php
defined('ABSPATH') || exit;

/**
 * Kiểm tra user có phải Premium không, theo level PMPro đã chọn trong
 * Settings > TTQ Freemium. Admin luôn được coi là Premium để tiện quản trị.
 *
 * @param int|null $user_id
 * @return bool
 */
function ttq_bm_is_premium($user_id = null) {
    $user_id = $user_id ?: get_current_user_id();

    if (!$user_id) {
        return false;
    }

    if (user_can($user_id, 'manage_options')) {
        return true;
    }

    $settings = TTQ_BM_Settings::get();

    if (empty($settings['premium_levels'])) {
        return false; // chưa cấu hình -> không ai được coi là Premium, tránh mở khóa nhầm
    }

    return pmpro_hasMembershipLevel($settings['premium_levels'], $user_id);
}

/**
 * Trả về post ID (bm-ai-chat-bot) tương ứng với một thread, nếu thread đó
 * là hội thoại với bot AI. Trả về 0 nếu không phải thread bot.
 *
 * @param int $thread_id
 * @return int
 */
function ttq_bm_get_thread_bot_id($thread_id) {
    $bot_id = Better_Messages()->functions->get_thread_meta($thread_id, 'ai_bot_thread');
    return $bot_id ? (int) $bot_id : 0;
}

/**
 * Key user_meta đếm số tin nhắn bot AI trong ngày hôm nay (theo giờ site).
 *
 * @return string
 */
function ttq_bm_today_counter_key() {
    return '_ttq_ai_' . gmdate('Ymd', current_time('timestamp'));
}

/**
 * Danh sách post ID bot mà Free được dùng, từ cấu hình admin.
 *
 * @return int[]
 */
function ttq_bm_free_bot_ids() {
    $settings = TTQ_BM_Settings::get();
    return $settings['free_bot_ids'];
}

/**
 * Giới hạn tin/ngày theo level của user.
 *
 * @param int $user_id
 * @return int
 */
function ttq_bm_daily_limit_for_user($user_id) {
    $settings = TTQ_BM_Settings::get();
    return ttq_bm_is_premium($user_id)
        ? (int) $settings['premium_daily_limit']
        : (int) $settings['free_daily_limit'];
}
