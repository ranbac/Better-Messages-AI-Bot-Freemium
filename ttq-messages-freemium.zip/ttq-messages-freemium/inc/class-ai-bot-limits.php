<?php
defined('ABSPATH') || exit;

/**
 * Giới hạn số tin nhắn/ngày gửi cho chat bot AI, theo cấu hình trong
 * Settings > TTQ Freemium (free_daily_limit / premium_daily_limit).
 *
 * QUAN TRỌNG: việc CHẶN và việc ĐẾM phải tách làm hai hook khác nhau.
 * 'better_messages_can_send_message' là một filter KIỂM TRA QUYỀN — nó
 * bị gọi lại nhiều lần cho cùng một tin nhắn (lúc load danh sách thread,
 * lúc polling, lúc refresh UI sau khi gửi...), không chỉ lúc gửi thật.
 * Nếu cộng số đếm ngay trong filter này, 1 tin nhắn sẽ bị trừ nhiều lượt.
 *
 * Vì vậy: filter chỉ ĐỌC số đã dùng để quyết định chặn hay không.
 * Việc CỘNG số đếm chuyển sang action 'better_messages_message_sent',
 * hook này chỉ bắn đúng 1 lần, sau khi tin nhắn đã lưu DB thành công.
 *
 * Đếm bằng user_meta, key đổi theo ngày (giờ site), tự dọn qua cron.
 */
class TTQ_BM_AI_Bot_Limits {

    public static function init() {
        // Priority 30: chạy SAU gate chặn bot premium (25) — không tính giới hạn
        // nếu user còn chưa được phép nhắn vào thread đó.
        add_filter('better_messages_can_send_message', array(__CLASS__, 'check_daily_limit'), 30, 3);

        // Cộng số đếm đúng 1 lần, khi tin nhắn thực sự được lưu thành công.
        add_action('better_messages_message_sent', array(__CLASS__, 'increment_after_send'), 10, 1);
    }

    /**
     * Chỉ KIỂM TRA, không cộng số đếm ở đây.
     *
     * @param bool $allowed
     * @param int  $user_id
     * @param int  $thread_id
     * @return bool
     */
    public static function check_daily_limit($allowed, $user_id, $thread_id) {
        if (!$allowed || $user_id <= 0) {
            return $allowed;
        }

        $bot_id = ttq_bm_get_thread_bot_id($thread_id);

        if (!$bot_id) {
            return $allowed; // không phải thread bot -> không giới hạn ở đây
        }

        $limit = ttq_bm_daily_limit_for_user($user_id);

        // limit = 0 nghĩa là admin đặt "không giới hạn" cho nhóm này
        if ($limit <= 0) {
            return $allowed;
        }

        $used = (int) get_user_meta($user_id, ttq_bm_today_counter_key(), true);

        if ($used >= $limit) {
            self::set_limit_error($user_id, $limit);
            return false;
        }

        return $allowed;
    }

    /**
     * Cộng số đếm sau khi tin nhắn đã lưu thành công — chạy đúng 1 lần/tin.
     *
     * @param object $message Đối tượng message, truyền theo reference.
     */
    public static function increment_after_send($message) {
        if (empty($message->thread_id) || empty($message->sender_id)) {
            return;
        }

        $user_id = (int) $message->sender_id;

        if ($user_id <= 0) {
            return; // tin nhắn từ bot (sender âm) hoặc hệ thống -> bỏ qua
        }

        $bot_id = ttq_bm_get_thread_bot_id((int) $message->thread_id);

        if (!$bot_id) {
            return; // không phải thread bot
        }

        $limit = ttq_bm_daily_limit_for_user($user_id);

        if ($limit <= 0) {
            return; // không giới hạn -> không cần đếm
        }

        $key  = ttq_bm_today_counter_key();
        $used = (int) get_user_meta($user_id, $key, true);

        update_user_meta($user_id, $key, $used + 1);
    }

    /**
     * @param int $user_id
     * @param int $limit
     */
    private static function set_limit_error($user_id, $limit) {
        global $bp_better_messages_restrict_send_message;

        $settings   = TTQ_BM_Settings::get();
        $is_premium = ttq_bm_is_premium($user_id);

        $bp_better_messages_restrict_send_message['ttq_ai_daily_limit'] = $is_premium
            ? sprintf(
                /* translators: %d: daily limit */
                __('Bạn đã dùng hết %d lượt chat AI hôm nay. Vui lòng quay lại vào ngày mai.', 'ttq-messages-freemium'),
                $limit
            )
            : sprintf(
                /* translators: 1: free limit, 2: premium limit */
                __('Bạn đã dùng hết %1$d lượt chat AI hôm nay. Nâng cấp VIP để có %2$d lượt/ngày.', 'ttq-messages-freemium'),
                $limit,
                (int) $settings['premium_daily_limit']
            );
    }
}
