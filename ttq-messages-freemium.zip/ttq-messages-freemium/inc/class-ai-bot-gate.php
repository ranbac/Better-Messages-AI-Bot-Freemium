<?php
defined('ABSPATH') || exit;

/**
 * Kiểm soát việc Free chỉ thấy / dùng được các bot AI đã chọn trong
 * Settings > TTQ Freemium. Premium thấy và dùng được tất cả.
 */
class TTQ_BM_AI_Bot_Gate {

    public static function init() {
        // Ẩn bot khỏi danh sách hiển thị cho Free
        add_filter('better_messages_get_ai_bots', array(__CLASS__, 'filter_bot_list'), 20, 2);

        // Chặn gửi tin nếu Free cố nhắn vào thread bot premium
        // (ví dụ: thread tạo từ trước khi hạ level, hoặc gọi thẳng REST API)
        add_filter('better_messages_can_send_message', array(__CLASS__, 'block_premium_bot_thread'), 25, 3);
    }

    /**
     * Lọc danh sách bot trả về cho client theo level.
     *
     * @param array $bots     Mảng bot, mỗi phần tử có key 'bot_user_id' (guest id âm).
     * @param int   $user_id
     * @return array
     */
    public static function filter_bot_list($bots, $user_id) {
        if (ttq_bm_is_premium($user_id)) {
            return $bots;
        }

        $free_bot_ids = ttq_bm_free_bot_ids();

        if (empty($free_bot_ids)) {
            return array(); // chưa cấu hình bot nào cho Free -> Free không thấy bot nào
        }

        global $wpdb;
        $guests_table = bm_get_table('guests');

        return array_values(array_filter($bots, function ($bot) use ($wpdb, $guests_table, $free_bot_ids) {
            $post_id = self::resolve_post_id_from_bot_user_id($wpdb, $guests_table, $bot['bot_user_id'] ?? 0);
            return $post_id && in_array($post_id, $free_bot_ids, true);
        }));
    }

    /**
     * Chặn gửi tin nếu thread là bot premium mà user hiện tại là Free.
     *
     * @param bool $allowed
     * @param int  $user_id
     * @param int  $thread_id
     * @return bool
     */
    public static function block_premium_bot_thread($allowed, $user_id, $thread_id) {
        if (!$allowed || $user_id <= 0 || ttq_bm_is_premium($user_id)) {
            return $allowed;
        }

        $bot_id = ttq_bm_get_thread_bot_id($thread_id);

        if (!$bot_id) {
            return $allowed; // không phải thread bot -> bỏ qua
        }

        if (!in_array($bot_id, ttq_bm_free_bot_ids(), true)) {
            global $bp_better_messages_restrict_send_message;
            $bp_better_messages_restrict_send_message['ttq_bot_premium_only'] =
                __('Trợ lý AI này chỉ dành cho học viên VIP. Nâng cấp để mở khóa tất cả bot.', 'ttq-messages-freemium');

            return false;
        }

        return $allowed;
    }

    /**
     * bot_user_id (guest id âm) -> guests.ip ("ai-chat-bot-{postID}") -> post ID.
     *
     * @param wpdb   $wpdb
     * @param string $guests_table
     * @param int    $bot_user_id
     * @return int 0 nếu không map được.
     */
    private static function resolve_post_id_from_bot_user_id($wpdb, $guests_table, $bot_user_id) {
        $guest_id = abs((int) $bot_user_id);
        if (!$guest_id) {
            return 0;
        }

        $ip = $wpdb->get_var($wpdb->prepare(
            "SELECT ip FROM {$guests_table} WHERE id = %d",
            $guest_id
        ));

        if (empty($ip) || strpos($ip, 'ai-chat-bot-') !== 0) {
            return 0;
        }

        return (int) str_replace('ai-chat-bot-', '', $ip);
    }
}
