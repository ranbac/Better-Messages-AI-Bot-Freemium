<?php
defined('ABSPATH') || exit;

/**
 * Đồng bộ với thay đổi membership PMPro:
 *   - Khi user đổi level (nâng cấp, hạ cấp, hết hạn) -> xoá counter hôm nay
 *     để họ không bị chặn oan ngay lập tức bởi số đếm cũ.
 */
class TTQ_BM_PMPro_Sync {

    public static function init() {
        add_action('pmpro_after_change_membership_level', array(__CLASS__, 'reset_today_counter'), 10, 2);
    }

    /**
     * @param int $level_id
     * @param int $user_id
     */
    public static function reset_today_counter($level_id, $user_id) {
        if (!$user_id) {
            return;
        }

        delete_user_meta($user_id, ttq_bm_today_counter_key());
    }
}
