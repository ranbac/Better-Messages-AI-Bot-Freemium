<?php
defined('ABSPATH') || exit;

/**
 * Trang cấu hình trong wp-admin: Settings > TTQ Freemium.
 * Cho phép chọn level PMPro nào là Premium, bot AI nào Free được dùng,
 * và số tin/ngày cho từng nhóm — không cần sửa code.
 */
class TTQ_BM_Settings {

    const OPTION_KEY = 'ttq_bm_freemium_settings';
    const PAGE_SLUG  = 'ttq-bm-freemium';

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'register_menu'));
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('admin_post_ttq_bm_reset_counters', array(__CLASS__, 'handle_reset_counters'));
        add_action('admin_notices', array(__CLASS__, 'maybe_show_reset_notice'));
    }

    /**
     * Giá trị mặc định khi chưa cấu hình gì.
     *
     * @return array
     */
    public static function defaults() {
        return array(
            'premium_levels'    => array(),
            'free_bot_ids'      => array(),
            'free_daily_limit'  => 5,
            'premium_daily_limit' => 20,
        );
    }

    /**
     * Đọc cấu hình hiện tại, merge với default để tránh key thiếu.
     *
     * @return array
     */
    public static function get() {
        $saved = get_option(self::OPTION_KEY, array());
        return wp_parse_args($saved, self::defaults());
    }

    public static function register_menu() {
        add_submenu_page(
            'bp-better-messages',
            __('TTQ Freemium', 'ttq-messages-freemium'),
            __('TTQ Freemium', 'ttq-messages-freemium'),
            'manage_options',
            self::PAGE_SLUG,
            array(__CLASS__, 'render_page'),
            10
        );
    }

    public static function register_settings() {
        register_setting(self::PAGE_SLUG, self::OPTION_KEY, array(
            'sanitize_callback' => array(__CLASS__, 'sanitize'),
        ));
    }

    /**
     * @param array $input
     * @return array
     */
    public static function sanitize($input) {
        $out = self::defaults();

        $out['premium_levels'] = isset($input['premium_levels'])
            ? array_map('intval', (array) $input['premium_levels'])
            : array();

        $out['free_bot_ids'] = isset($input['free_bot_ids'])
            ? array_map('intval', (array) $input['free_bot_ids'])
            : array();

        $out['free_daily_limit'] = isset($input['free_daily_limit'])
            ? max(0, (int) $input['free_daily_limit'])
            : 5;

        $out['premium_daily_limit'] = isset($input['premium_daily_limit'])
            ? max(0, (int) $input['premium_daily_limit'])
            : 20;

        return $out;
    }

    /**
     * Xóa toàn bộ số đếm lượt chat AI của TẤT CẢ user (mọi ngày, không chỉ hôm nay).
     * Dùng WP_User_Query + delete_user_meta — không cần chạy SQL thủ công.
     * Gọi qua nút "Xóa số đếm" trên trang settings.
     */
    public static function handle_reset_counters() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Bạn không có quyền thực hiện thao tác này.', 'ttq-messages-freemium'));
        }

        check_admin_referer('ttq_bm_reset_counters');

        global $wpdb;

        // Lấy tất cả meta_key dạng _ttq_ai_YYYYMMDD đang tồn tại trong hệ thống,
        // rồi xóa qua delete_user_meta cho từng user — an toàn hơn DELETE thẳng
        // vì đi qua API chuẩn của WordPress (tự dọn cache đối tượng liên quan).
        $keys = $wpdb->get_col(
            "SELECT DISTINCT meta_key FROM {$wpdb->usermeta}
             WHERE meta_key REGEXP '^_ttq_ai_[0-9]{8}$'"
        );

        $deleted_users = 0;

        if (!empty($keys)) {
            foreach ($keys as $key) {
                $user_ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s",
                    $key
                ));

                foreach ($user_ids as $user_id) {
                    delete_user_meta((int) $user_id, $key);
                    $deleted_users++;
                }
            }
        }

        $redirect = add_query_arg(
            array(
                'page'              => self::PAGE_SLUG,
                'ttq_reset_done'    => 1,
                'ttq_reset_count'   => $deleted_users,
            ),
            admin_url('admin.php')
        );

        wp_safe_redirect($redirect);
        exit;
    }

    /**
     * Hiện thông báo xác nhận sau khi bấm nút xóa số đếm.
     */
    public static function maybe_show_reset_notice() {
        if (empty($_GET['ttq_reset_done']) || empty($_GET['page']) || $_GET['page'] !== self::PAGE_SLUG) {
            return;
        }

        $count = isset($_GET['ttq_reset_count']) ? (int) $_GET['ttq_reset_count'] : 0;
        ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <?php
                printf(
                    /* translators: %d: số bản ghi đã xóa */
                    esc_html__('Đã xóa số đếm lượt chat AI (%d bản ghi). Tất cả người dùng có thể chat lại từ đầu.', 'ttq-messages-freemium'),
                    $count
                );
                ?>
            </p>
        </div>
        <?php
    }

    /**
     * Danh sách tất cả level PMPro (kể cả level đã ẩn), lấy trực tiếp từ bảng PMPro.
     *
     * @return array Mảng object level (id, name).
     */
    private static function get_all_pmpro_levels() {
        if (!function_exists('pmpro_getAllLevels')) {
            return array();
        }
        // true, true = lấy cả level ẩn/không cho đăng ký, để admin vẫn thấy đủ danh sách
        return pmpro_getAllLevels(true, true);
    }

    /**
     * Danh sách tất cả bot AI (post type bm-ai-chat-bot), kể cả bot đang tắt.
     *
     * @return WP_Post[]
     */
    private static function get_all_bots() {
        $query = new WP_Query(array(
            'post_type'      => 'bm-ai-chat-bot',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ));
        return $query->posts;
    }

    public static function render_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = self::get();
        $levels   = self::get_all_pmpro_levels();
        $bots     = self::get_all_bots();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('TTQ Messages Freemium — Cấu hình', 'ttq-messages-freemium'); ?></h1>
            <p><?php esc_html_e('Chọn level PMPro nào được coi là Premium, và bot AI nào người dùng Free được phép dùng.', 'ttq-messages-freemium'); ?></p>

            <form method="post" action="options.php">
                <?php settings_fields(self::PAGE_SLUG); ?>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('Level Premium', 'ttq-messages-freemium'); ?></th>
                        <td>
                            <?php if (empty($levels)) : ?>
                                <p class="description">
                                    <?php esc_html_e('Không tìm thấy level PMPro nào. Kiểm tra plugin Paid Memberships Pro đã kích hoạt chưa.', 'ttq-messages-freemium'); ?>
                                </p>
                            <?php else : ?>
                                <fieldset>
                                    <?php foreach ($levels as $level) : ?>
                                        <label style="display:block;margin-bottom:6px;">
                                            <input
                                                type="checkbox"
                                                name="<?php echo esc_attr(self::OPTION_KEY); ?>[premium_levels][]"
                                                value="<?php echo esc_attr($level->id); ?>"
                                                <?php checked(in_array((int) $level->id, $settings['premium_levels'], true)); ?>
                                            />
                                            <?php echo esc_html($level->name); ?>
                                            <span class="description">(ID: <?php echo esc_html($level->id); ?>)</span>
                                        </label>
                                    <?php endforeach; ?>
                                </fieldset>
                                <p class="description">
                                    <?php esc_html_e('Level không được chọn (kể cả TRIAL/free) sẽ bị coi là nhóm Free.', 'ttq-messages-freemium'); ?>
                                </p>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php esc_html_e('Bot AI cho Free', 'ttq-messages-freemium'); ?></th>
                        <td>
                            <?php if (empty($bots)) : ?>
                                <p class="description">
                                    <?php esc_html_e('Chưa có bot AI nào được tạo (hoặc tất cả đang ở trạng thái nháp).', 'ttq-messages-freemium'); ?>
                                </p>
                            <?php else : ?>
                                <fieldset>
                                    <?php foreach ($bots as $bot) : ?>
                                        <label style="display:block;margin-bottom:6px;">
                                            <input
                                                type="checkbox"
                                                name="<?php echo esc_attr(self::OPTION_KEY); ?>[free_bot_ids][]"
                                                value="<?php echo esc_attr($bot->ID); ?>"
                                                <?php checked(in_array((int) $bot->ID, $settings['free_bot_ids'], true)); ?>
                                            />
                                            <?php echo esc_html($bot->post_title); ?>
                                            <span class="description">(ID: <?php echo esc_html($bot->ID); ?>)</span>
                                        </label>
                                    <?php endforeach; ?>
                                </fieldset>
                                <p class="description">
                                    <?php esc_html_e('Bot không được chọn sẽ chỉ hiển thị và dùng được cho Premium.', 'ttq-messages-freemium'); ?>
                                </p>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="ttq_free_daily_limit"><?php esc_html_e('Giới hạn tin/ngày — Free', 'ttq-messages-freemium'); ?></label>
                        </th>
                        <td>
                            <input
                                type="number"
                                id="ttq_free_daily_limit"
                                name="<?php echo esc_attr(self::OPTION_KEY); ?>[free_daily_limit]"
                                value="<?php echo esc_attr($settings['free_daily_limit']); ?>"
                                min="0"
                                step="1"
                                class="small-text"
                            />
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="ttq_premium_daily_limit"><?php esc_html_e('Giới hạn tin/ngày — Premium', 'ttq-messages-freemium'); ?></label>
                        </th>
                        <td>
                            <input
                                type="number"
                                id="ttq_premium_daily_limit"
                                name="<?php echo esc_attr(self::OPTION_KEY); ?>[premium_daily_limit]"
                                value="<?php echo esc_attr($settings['premium_daily_limit']); ?>"
                                min="0"
                                step="1"
                                class="small-text"
                            />
                        </td>
                    </tr>
                </table>

                <?php submit_button(__('Lưu cấu hình', 'ttq-messages-freemium')); ?>
            </form>

            <hr />

            <h2><?php esc_html_e('Xóa số đếm lượt chat', 'ttq-messages-freemium'); ?></h2>
            <p class="description">
                <?php esc_html_e('Dùng khi cần cho phép mọi người chat lại từ đầu (ví dụ: vừa sửa xong lỗi đếm sai, hoặc muốn reset thủ công). Thao tác này xóa số đếm của TẤT CẢ người dùng, không ảnh hưởng đến cấu hình phía trên.', 'ttq-messages-freemium'); ?>
            </p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="ttq_bm_reset_counters" />
                <?php wp_nonce_field('ttq_bm_reset_counters'); ?>
                <?php submit_button(__('Xóa số đếm', 'ttq-messages-freemium'), 'secondary', 'submit', false); ?>
            </form>
        </div>
        <?php
    }
}
